import styles from '../../styles/alert.module.css';
// import cn from 'clsx';

// idk what i'm doing. clsx/cn doesn't exist and idk what it does. not this tho. doesn't work
// function cn(){
//    return <div>"success"</div>;
// };

export default function Alert({ children, type }) {
  return (
    <div>Placeholder</div>

    // <div
    //   className={cn({
    //     [styles.success]: type === 'success',
    //     [styles.error]: type === 'error',
    //   })}
    // >
    //   {children}
    // </div>
  );
}

// https://nextjs.org/learn/basics/assets-metadata-css/styling-tips